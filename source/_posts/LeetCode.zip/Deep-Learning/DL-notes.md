---
title: DL-notes:目录
date: 2024-05-07 12:36:52
tags: [DL-notes,DL,notes]
categories: [深度学习,笔记]
---

## 目录

### {% post_link DL-notes/pages/HwAlg '1 常见算法' %}



## 参考
[李宏毅深度学习教程LeeDL-Tutorial](https://datawhalechina.github.io/leedl-tutorial/#/)
[邱锡鹏神经网络与深度学习NNDL](https://nndl.github.io/)

